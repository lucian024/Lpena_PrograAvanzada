#!/bin/bash 

#Instalacion de wget en el sistema
sudo apt-get install wget
clear
echo "wget instalado"

#Creacion de directorios para alojar archivos del analisis
mkdir $HOME/ArchivosTemporales
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2010-2011.csv"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2011-2012.csv	"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2012-2013.csv"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2013-2014.csv"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2014-2015a.csv"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/data/Panguilemodetalle2014-2015b.csv"  >> $HOME/ArchivosTemporales/lista.txt
echo "https://srvbioinf1.utalca.cl/~fduran/scripts.zip" >> $HOME/ArchivosTemporales/lista.txt

#Descarga de archivos csv y .py los cuales se alojaran en carpeta creada anteriormente       
wget -P $HOME/ArchivosTemporales -i $HOME/ArchivosTemporales/lista.txt 

#Creacion de directorios para alojar resultados
mkdir $HOME/ArchivosTemporales/Resultados
mkdir $HOME/ArchivosTemporales/Resultados/2010
mkdir $HOME/ArchivosTemporales/Resultados/2011
mkdir $HOME/ArchivosTemporales/Resultados/2012
mkdir $HOME/ArchivosTemporales/Resultados/2013
mkdir $HOME/ArchivosTemporales/Resultados/2014
mkdir $HOME/ArchivosTemporales/Resultados/2015

#Orden de archivos por su año, se filtra cada archivo por el año que
#corresponde a cada uno y se envia a un archivo.txt
cd $HOME/ArchivosTemporales
cat Panguilemodetalle2010-2011.csv | grep "2010" >> Resultados2010.txt
cat Panguilemodetalle2010-2011.csv | grep "2011" >> Resultados2011.txt
cat Panguilemodetalle2011-2012.csv | grep "2011" >> Resultados2011.txt
cat Panguilemodetalle2011-2012.csv | grep "2012" >> Resultados2012.txt
cat Panguilemodetalle2012-2013.csv | grep "2012" >> Resultados2012.txt
cat Panguilemodetalle2012-2013.csv | grep "2013" >> Resultados2013.txt
cat Panguilemodetalle2013-2014.csv | grep "2013" >> Resultados2013.txt
cat Panguilemodetalle2013-2014.csv | grep "2014" >> Resultados2014.txt
cat Panguilemodetalle2014-2015a.csv | grep "2014" >> Resultados2014.txt
cat Panguilemodetalle2014-2015b.csv | grep "2014" >> Resultados2014.txt
cat Panguilemodetalle2014-2015a.csv | grep "2015" >> Resultados2015.txt
cat Panguilemodetalle2014-2015b.csv | grep "2015" >> Resultados2015.txt


#Eliminacion de archivos temporales
rm $HOME/ArchivosTemporales/lista.txt 
rm $HOME/ArchivosTemporales/Panguilemodetalle2010-2011.csv
rm $HOME/ArchivosTemporales/Panguilemodetalle2011-2012.csv
rm $HOME/ArchivosTemporales/Panguilemodetalle2012-2013.csv
rm $HOME/ArchivosTemporales/Panguilemodetalle2013-2014.csv
rm $HOME/ArchivosTemporales/Panguilemodetalle2014-2015a.csv
rm $HOME/ArchivosTemporales/Panguilemodetalle2014-2015b.csv


#Descompresion del archivo .py para generar graficos y se eliminan los
#archivos innecesarios
cd $HOME/ArchivosTemporales
unzip scripts.zip
rm scripts.zip
cd $HOME/ArchivosTemporales/scripts
rm graficoHumedad.png 
rm graficoHumedad2010.png
rm graficoTemperatura.png
rm humedad.csv
rm temperatura.csv
rm README

#Se limpia la consola y se envia mensaje al usuario
clear
echo "Descarga de archivos.csv finalizada"

