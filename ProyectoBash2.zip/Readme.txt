

Program for displaying graphics generated from data obtained from the automatic weather station (E.M.A)



1._  Run the INSTALL.sh script on the console

2._To obtain the graphics:

-> for the year 2010 execute the following command example: " bash estadisticas2010.sh "

-> for the years 2011-2012-2013-2014 execute the following command, for example: " bash estadisticas.sh 2011 "

-> for the year 2015 execute the following command example: " bash estadisticas2015.sh "





