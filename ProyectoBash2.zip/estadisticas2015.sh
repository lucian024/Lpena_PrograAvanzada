#!/bin/bash 
#Se repite la logica del script estadisticas.sh para obtener los resultados de este año
direccion=$HOME/ArchivosTemporales/Resultados2015.txt
cd $HOME/ArchivosTemporales/Resultados/2015
touch Temperatura.csv
touch Humedad.csv

####temperatura#####
for i in `seq 1 4`;
do
	suma_mes=$(cat $direccion | grep "2015-0$i" | awk -F";" '{suma += $6} END {print suma}')
	suma_linea=$(cat $direccion | grep "2015-0$i" | wc -l )
	echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/2015/Temperatura.csv
			
done

###### humedad#######

for i in `seq 1 4`;
do

	suma_mes=$(cat $direccion | grep "2015-0$i" | awk -F";" '{suma += $7} END {print suma}')
	suma_linea=$(cat $direccion | grep "2015-0$i" | wc -l )
	echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/2015/Humedad.csv

done
	
#Generacion de graficos
cd $HOME/ArchivosTemporales/scripts
#Humedad
python -Wignore generateGraphic.py $HOME/ArchivosTemporales/Resultados/2015 'GraficoHumedad' $HOME/ArchivosTemporales/Resultados/2015/Humedad.csv "Meses" "Porcentaje %" "Promedio humedad año 2015"
#Temperatura
python -Wignore generateGraphic.py $HOME/ArchivosTemporales/Resultados/2015 'GraficoTemperatura' $HOME/ArchivosTemporales/Resultados/2015/Temperatura.csv "Meses" "Grados" "Promedio Temperatura año 2015"

echo "Graficos generados"
echo "Abriendo..."
#Apertura de graficos
cd $HOME/ArchivosTemporales/Resultados/2015
eog GraficoHumedad.png

#Limpieza de archivos 
cd $HOME/ArchivosTemporales/Resultados/2015
rm Temperatura.csv
rm Humedad.csv

#Mensaje para el usuario
echo "▓▓▓▓▓▓▓▓▓▓▓▓████████████
▓▓▓▓▓▓▓▓███████▒▒▒▒▒▒▒▒▒███
▓▓▓▓▓█████████▒▒▒▒▒▒▒▒▒▒▒▒████
▓▓▓▓██▒███▒▒▒▒██▒▒▒▒▒▒▒▒▒█▒▒▒██
▓▓▓█▒▒▒█▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒▒██
▓▓█▒▒▒█▒▒▒▒▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
▓█▒▒▒██▒▒▒▒▒▒▒▒▒█████████▒▒▒▒▒▒▒▒█
██▒▒▒█▒▒▒▒▒▒▒▒▒▒██████████▒▒▒▒▒▒▒▒█
█▒▒▒██▒▒▒▒▒▒▒▒████████████▒▒▒▒▒▒▒▒█
█▒▒█████▒▒▒███▒▒▒███████▒▒████▒▒▒██
███████████▒▒▒▒▒▒▒▒███▒▒▒▒▒▒▒▒█████
█▒███████▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒████
█▒███████▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒████
▓█▒██████▒▒▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒▒▒███
▓▓█▒██▒▒██▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒██▒██
▓▓▓██▒▒▒▒▒███▒▒▒▒█████▒▒▒▒███▒▒▒█
▓▓▓▓██▒▒▒▒▒▒███████████████▒▒▒██
▓▓▓▓▓███▒▒▒▒▒▒██████████▒▒▒▒██
▓▓▓▓▓▓▓████▒▒▒█████████▒▒███
▓▓▓▓▓▓▓▓▓▓█████▒▒▒▒▒▒████
"
