#!/bin/bash 

#Declaracion de variables direccion que usa parametro
direccion=$HOME/ArchivosTemporales/Resultados$1.txt
#se crean archivos para alojar los datos de temperatura y humedad
cd $HOME/ArchivosTemporales/Resultados/$1
touch Temperatura.csv
touch Humedad.csv

####temperatura#####
#Bucle que sea realiza 12 veces para recorrer asi los 12 meses del año
for i in `seq 1 12`;
do
	#Se filtra por el mes del año el archivo deseado el usuario y se calcula el promedio mensual,
	#el resultado es enviado a un archivo .csv
	#La estructura condicional es porque los meses se expresan en numeros de dos cifras
	if [ $i -lt 10 ];
	then 
		suma_mes=$(cat $direccion | grep "$1-0$i" | awk -F";" '{suma += $6} END {print suma}')
		suma_linea=$(cat $direccion | grep "$1-0$i" | wc -l )
		echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/$1/Temperatura.csv
			
	
	else	
		suma_mes=$(cat $direccion | grep "$1-$i" | awk -F";" '{suma += $6} END {print suma}'  	)
		suma_linea=$(cat $direccion | grep "$1-$i" | wc -l )
		echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/$1/Temperatura.csv
		
	fi
	
done

###### humedad#######
#Se repite el mismo proceso anterior para generar resultados para la humedad
for i in `seq 1 12`;
do
	if [ $i -lt 10 ];
	then 
		suma_mes=$(cat $direccion | grep "$1-0$i" | awk -F";" '{suma += $7} END {print suma}')
		suma_linea=$(cat $direccion | grep "$1-0$i" | wc -l )
		echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/$1/Humedad.csv
			
	
	else	
		suma_mes=$(cat $direccion | grep "$1-$i" | awk -F";" '{suma += $7} END {print suma}'  	)
		suma_linea=$(cat $direccion | grep "$1-$i" | wc -l )
		echo $i";"`bc -l <<< $suma_mes/$suma_linea` >> $HOME/ArchivosTemporales/Resultados/$1/Humedad.csv
		
	fi
	
done

			
#Generacion de graficos para humedad y temperatura

cd $HOME/ArchivosTemporales/scripts
#Humedad
python -Wignore generateGraphic.py $HOME/ArchivosTemporales/Resultados/$1 'GraficoHumedad' $HOME/ArchivosTemporales/Resultados/$1/Humedad.csv "Meses" "Porcentaje %" "Promedio humedad año $1"
#Temperatura
python -Wignore generateGraphic.py $HOME/ArchivosTemporales/Resultados/$1 'GraficoTemperatura' $HOME/ArchivosTemporales/Resultados/$1/Temperatura.csv "Meses" "Grados" "Promedio Temperatura año $1"

#Mensaje para el usuario
echo "Graficos generados"
echo "Abriendo..."

#Apertura de graficos
cd $HOME/ArchivosTemporales/Resultados/$1
eog GraficoHumedad.png

#Limpieza de archivos 
cd $HOME/ArchivosTemporales/Resultados/$1
rm Temperatura.csv
rm Humedad.csv




