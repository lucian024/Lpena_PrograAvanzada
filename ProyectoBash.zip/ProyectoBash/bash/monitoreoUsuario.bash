#!/bin/bash

mkdir $HOME/informes
touch $HOME/informes/info.txt


