#!/bin/bash

$1
direcciones=$(find . $HOME -type f -iname $1)

echo "Coincidencias"
echo "---------------------------------------------------------------------------------------------------------"
for i in $( ls $direcciones )
do
	echo `file $i | awk '{print "Direccion:" $1 " / " "Tipo de archivo:" $2}'`
done
echo "---------------------------------------------------------------------------------------------------------"


