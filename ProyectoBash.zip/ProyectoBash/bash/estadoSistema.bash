#!/bin/bash
clear

echo "Fecha: " `date +%A' '%d' de '%B' del '%Y` " | " 'Hora actual: ' `date +%H":"%M`

echo "Nombre de la maquina: " `hostname`

echo "Estado de CPU :"

top -bn1 | grep "%Cpu" | awk '{print "Ocupado por : Usuario " $2"%" " | Sistema: " $4"%" " | Inactivo: " $8"%" }'

echo "Estado de memoria RAM: "
free -h | grep -i m | awk '{print "Total: "$2 " En uso: "$3 " Libre: "$4}'


echo "Estado de disco duro: "
df -h | grep -i G | sort -n | head -n1 | awk '{print " Disco: " $1 " / Total: " $2 " En uso: "$3}'



echo "Usuario: " `who |awk '{print $1}'`
echo "Tiempo de login: " `uptime -p`

echo "Cantidad de archivos en su /home: " `find $HOME -type f | wc -l`
echo "Mbytes de su /home: " `du $HOME -s -m |awk '{print $1}'`	
echo "-------------------------------------------------------------------------------------------"


