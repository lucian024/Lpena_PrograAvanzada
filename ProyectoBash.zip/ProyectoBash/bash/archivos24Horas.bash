#!/bin/bash

find . -mtime 0 -printf '%T+\t%s\t%p\n' 2>/dev/null | sort -r | awk '{print "Fecha-Hora: "$1 " | Nombre archivo:  "$3 }'

