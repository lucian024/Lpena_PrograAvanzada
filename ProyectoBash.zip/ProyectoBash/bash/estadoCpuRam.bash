#!/bin/bash

$1
echo "----------------------------------------------------------------------------------------------------"
if [ "$1" = "6" ];
then
	echo "Procesos que mas CPU consumen: "
	ps -eo cmd,%cpu --sort=-%cpu | head -n 4
fi	

if [ "$1" = "7" ];
then
	echo "Procesos que mas RAM consumen: "
	ps -eo cmd,%mem --sort=-%mem | head -n 4
fi
echo "----------------------------------------------------------------------------------------------------"

