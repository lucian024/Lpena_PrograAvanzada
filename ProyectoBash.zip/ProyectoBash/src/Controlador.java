import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Controlador {
    private Scanner scanner;


    public Controlador() {
        this.scanner = new Scanner(System.in);
        estadoInicial();
    }

    public void estadoInicial()
    {
        try{
            Process p = Runtime.getRuntime().exec("./bash/estadoSistema.bash");
            BufferedReader inicioPrograma = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = inicioPrograma.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    public void menuPrincipal()
    {
        int opcion = 0;

        while(true)
        {
            System.out.println("###   MENU PRINCIPAL   ###");
            System.out.println("[1] Visualizar usuarios");
            System.out.println("[2] Ficheros y procesos");
            System.out.println("[3] Actividad usuarios");
            System.out.print("Ingrese opcion: ");
            opcion = scanner.nextInt();

            switch (opcion)
            {
                case 1: menuVisualizarUsuarios(); break;
                case 2: menuFicherosProcesos(); break;
                case 3: menuActividadUsuario(); break;
            }

        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////
    public void menuVisualizarUsuarios()
    {
        int opcion = 0;

        while (true)
        {
            System.out.println("###   MENU USUARIOS   ###");
            System.out.println("[1] Visualizar usuarios reales + UID");
            System.out.println("[2] Buscar usuario por inicial");
            System.out.println("[3] Volver a menu principal");
            System.out.print("Ingrese opcion: ");
            opcion = scanner.nextInt();
            switch (opcion)
            {
                case 1: mostrarUsuariosReales();break;
                case 2: buscarUsuario(); break;
                case 3: menuPrincipal();break;
            }
        }

    }

    public void buscarUsuario()
    {

        String letraFiltro;
        System.out.println("Ingrese letra para iniciar filtrado");
        scanner.nextLine();
        letraFiltro = scanner.nextLine();

        try{

            Process p = Runtime.getRuntime().exec("./bash/buscarUsuario.bash " + letraFiltro);
            BufferedReader busquedaUsuario = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            System.out.println("Usuarios encontrados:");
            while ((line = busquedaUsuario.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }

    }
    public void mostrarUsuariosReales()
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/visualizarUsuarios.bash ");
            BufferedReader visualizarUsuarios = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = visualizarUsuarios.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    public void menuFicherosProcesos()
    {
        int opcion = 0;

        try{

            Process p = Runtime.getRuntime().exec("./bash/inicioFicherosProcesos.bash ");
            BufferedReader inicioFicherosProcesos = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = inicioFicherosProcesos.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }

        while(true)
        {
            System.out.println("###   MENU FICHEROS Y PROCESOS   ###");
            System.out.println("[1] Nombre de ficheros del usuario ordenados");
            System.out.println("[2] Nombre de directorios del usuario ordenados");
            System.out.println("[3] Archivos >1024Kb ordenados");
            System.out.println("[4] Buscar archivo ");
            System.out.println("[5] Buscar directorio ");
            System.out.println("[6] 3 Procesos que consumen más CPU");
            System.out.println("[7] 3 Procesos que consumen más RAM");
            System.out.println("[8] Volver a menu principal");
            System.out.print("Ingrese opcion: ");
            opcion = scanner.nextInt();

            switch (opcion)
            {
                case 1: ficherosOrdenados() ; break;
                case 2: directoriosOrdenados(); break;
                case 3: archivosOrdenadosTamaño();break;
                case 4: buscarArchivo(); break;
                case 5: buscarDirectorio();break;
                case 6: usoCpuRam(opcion);break;
                case 7: usoCpuRam(opcion);break;
                case 8: menuPrincipal(); break;
            }
        }
    }

    public void ficherosOrdenados()
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/ficherosOrdenados.bash ");
            BufferedReader ficherosOrdenados = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = ficherosOrdenados.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    public  void directoriosOrdenados()
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/directoriosOrdenados.bash ");
            BufferedReader directoriosOrdenados = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = directoriosOrdenados.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    public void archivosOrdenadosTamaño()
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/archivosGrandesOrdenados.bash ");
            BufferedReader archivosOrdenados = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = archivosOrdenados.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    public void buscarArchivo()
    {
        String nombre;
        System.out.println("Ingrese nombre del archivo (Ejemplo: archivo.extension)");
        scanner.nextLine();
        nombre = scanner.nextLine();

        try{

            Process p = Runtime.getRuntime().exec("./bash/buscadorArchivos.bash "+nombre);
            BufferedReader buscadorArchivos = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = buscadorArchivos.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }

    }
    public void buscarDirectorio()
    {
        String nombre;
        System.out.println("Ingrese nombre del directorio (Ejemplo: desCargAs)");
        scanner.nextLine();
        nombre = scanner.nextLine();

        try{

            Process p = Runtime.getRuntime().exec("./bash/buscadorDirectorio.bash "+nombre);
            BufferedReader buscadorDirectorio = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = buscadorDirectorio.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    public void usoCpuRam(int opcion)
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/estadoCpuRam.bash "+opcion);
            BufferedReader estadoCpuRam = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = estadoCpuRam.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    public void menuActividadUsuario() {

        try{

            Process p = Runtime.getRuntime().exec("./bash/monitoreoUsuario.bash ");
            BufferedReader monitoreoUsuario = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = monitoreoUsuario.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }

        int opcion = 0;

        while (true)
        {
            System.out.println("[1] Lista de arhivos modificados en las ultimas 24 horas");
            System.out.print("Ingrese una opcion :");
            opcion = scanner.nextInt();

            switch (opcion)
            {
                case 1: archivos24Horas(); break;
            }
        }

    }
    public  void archivos24Horas()
    {
        try{

            Process p = Runtime.getRuntime().exec("./bash/archivos24Horas.bash");
            BufferedReader archivos24Horas = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = null;

            while ((line = archivos24Horas.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
}
